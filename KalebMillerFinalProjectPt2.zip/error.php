<!DOCTYPE html>
<html>
    <head>
        <title>Error</title>
    </head>
    <body>
        <h1>Error encountered</h1>
        <p>missing id</p>
    </body>
</html>