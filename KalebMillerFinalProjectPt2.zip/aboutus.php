<!DOCTYPE HTML> 
<html>
    <head>
        <title>About</title>
    </head>
    <body>
        <?php
            require_once("navbar.php");
        ?>
        <div class="jumbotron text-center">
            <h1>Travel Review Site</h1>
            <h3>This is a hypothetical site for people to post pictures, reviews, and ratings for trips that they go on</h3>
            <h4>This site is the final project for CS 44106 - Web Programming 2 at Kent State University taught by Dr. A. Guergcio</h4>
            <h5>Kaleb Miller</h5>
            <h5>4/21/2023</h5>
            
        </div>
    </body>
</html>